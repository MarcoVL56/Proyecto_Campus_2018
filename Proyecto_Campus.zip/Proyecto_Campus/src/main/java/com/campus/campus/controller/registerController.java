package com.campus.campus.controller;

import com.campus.campus.entity.estudiante;
import com.campus.campus.model.connection;
import com.campus.campus.view.JFRegister;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;

/**
 *
 * @author Adriel
 */
public class registerController implements ActionListener {

    JFRegister registerView = new JFRegister();
    connection con;

    public registerController() throws SQLException {
        registerView.setVisible(true);
        registerView.setLocationRelativeTo(null);
        registerView.cmbProvincia.addActionListener(this);
        registerView.cmbCanton.addActionListener(this);
        registerView.cmbDistrito.addActionListener(this);
       
        con = new connection();
        
        
        
        
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == registerView.cmbProvincia) {
            try {
                setCmbCanton(registerView.cmbProvincia.getSelectedItem().toString());
            } catch (SQLException ex) {
                Logger.getLogger(registerController.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        if (e.getSource() == registerView.cmbCanton) {
            setcmbDistrito(registerView.cmbCanton.getSelectedItem().toString());
        }
        if (e.getSource() == registerView.cmbCanton) {
            setcmbDistrito(registerView.cmbCanton.getSelectedItem().toString());
        }

        if (e.getSource() == registerView.btnregistro) {
        }
        
        
    if (!verificarEspacios()) {
//                try {
//                    estudiante.setIdEstudiante(registerView.txtcedula.getText());
//                    estudiante.setNombre(registerView.txtnombre.getText());
//                    estudiante.setApellido1(registerView.txtape1.getText());
//                    estudiante.setApellido2(registerView.txtape2.getText());
//                    estudiante.setNumeroTelefonico(registerView.txttelefono.getText());
//                    estudiante.setDireccion(registerView.txtdireccion.getText());
//                    estudiante.setId_usuario(registerView.txtusuario.getText());
//                    estudiante.setclave(registerView.txtpass.getText());
//
//                    registroDAO.Guardar(estudiante);
//                    cargarPersonas();
//                } catch (Exception ex) {
//                    System.out.println("ERROR----" + ex);
//                }
            }

        if (e.getSource() == registerView.cmbCanton) {
            setcmbDistrito(registerView.cmbCanton.getSelectedItem().toString());
        }


    }

    private void setCmbCanton(String provincia) throws SQLException {
//        PreparedStatement ps = accesoDB.prepareStatement("INSERT INTO estudiante VALUES (?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?)");
//        ResultSet rs = ps.executeQuery();

        DefaultComboBoxModel model = new DefaultComboBoxModel();

        switch (provincia) {
            case "San José":
                model.addElement("San José");
                model.addElement("Escazú");
                model.addElement("Desamparados");
                model.addElement("Puriscal");
                model.addElement("Tarrazú");
                model.addElement("Aserrí");
                model.addElement("Mora");
                model.addElement("Goicoechea");
                model.addElement("Santa Ana");
                model.addElement("Alajuelita");
                model.addElement("Vásquez de Coronado");
                model.addElement("Acosta");
                model.addElement("Tibás");
                model.addElement("Moravia");
                model.addElement("Montes de Oca");
                model.addElement("Turrubares");
                model.addElement("Dota");
                model.addElement("Curridabat");
                model.addElement("Pérez Zeledón");
                model.addElement("León Cortés");

                registerView.cmbCanton.setModel(model);
                break;
            case "Alajuela":
                model.addElement("Alajuela");
                model.addElement("San Ramón");
                model.addElement("Grecia");
                model.addElement("San Mateo");
                model.addElement("Atenas");
                model.addElement("Naranjo");
                model.addElement("Palmares");
                model.addElement("Poás");
                model.addElement("Orotina");
                model.addElement("San Carlos");
                model.addElement("Zarcero");
                model.addElement("Sarchí");
                model.addElement("Upala");
                model.addElement("Los Chiles");
                model.addElement("Guatuso");

                registerView.cmbCanton.setModel(model);
                break;
            case "Cartago":
                model.addElement("Cartago");
                model.addElement("Paraíso");
                model.addElement("La Unión");
                model.addElement("Jiménez");
                model.addElement("Turrialba");
                model.addElement("Alvarado");
                model.addElement("Oreamuno");
                model.addElement("El Guarco");

                registerView.cmbCanton.setModel(model);
                break;
            case "Heredia":
                model.addElement("Heredia");
                model.addElement("Barva");
                model.addElement("Santo Domingo");
                model.addElement("Santa Bárbara");
                model.addElement("San Rafael");
                model.addElement("San Isidro");
                model.addElement("Belén");
                model.addElement("Flores");
                model.addElement("San Pablo");
                model.addElement("Sarapiquí");

                registerView.cmbCanton.setModel(model);
                break;
            case "Guanacaste":
                model.addElement("Liberia");
                model.addElement("Nicoya");
                model.addElement("Santa Cruz");
                model.addElement("Bagaces");
                model.addElement("Carrillo");
                model.addElement("Cañas");
                model.addElement("Abangares");
                model.addElement("Tilarán");
                model.addElement("Nandayure");
                model.addElement("La Cruz");
                model.addElement("Hojancha");

                registerView.cmbCanton.setModel(model);
                break;
            case "Puntarenas":
                model.addElement("Puntarenas");
                model.addElement("Esparza");
                model.addElement("Buenos Aires");
                model.addElement("Montes de Oro");
                model.addElement("Osa");
                model.addElement("Quepos");
                model.addElement("Golfito");
                model.addElement("Coto Brus");
                model.addElement("Parrita");
                model.addElement("Corredores");
                model.addElement("Garabito");

                registerView.cmbCanton.setModel(model);
                break;
            case "Limón":
                model.addElement("Limón");
                model.addElement("Pococí");
                model.addElement("Siquirres");
                model.addElement("Talamanca");
                model.addElement("Matina");
                model.addElement("Guácimo");

                registerView.cmbCanton.setModel(model);
                break;
        }

    }

    public void setcmbDistrito(String canton) {

        DefaultComboBoxModel model = new DefaultComboBoxModel();

        switch (canton) {
            //San Jose
            case "San José":
                model.addElement("Carmen");
                model.addElement("Merced");
                model.addElement("Hospital");
                model.addElement("Catedral");
                model.addElement("Zapote");
                model.addElement("San Francisco de Dos Rios");
                model.addElement("La Uruca");
                model.addElement("Mata Redonda");
                model.addElement("Pavas");
                model.addElement("Hatillo");
                model.addElement("San Sebastian");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Escazú":
                model.addElement("San Miguel");
                model.addElement("San Antonio");
                model.addElement("San Rafael");
                registerView.cmbDistrito.setModel(model);
                break;

            case "Desamparados":
                model.addElement("Desamparados");
                model.addElement("San Miguel");
                model.addElement("San Juan de Dios");
                model.addElement("San Rafael Arriba");
                model.addElement("San Antonio");
                model.addElement("Frailes");
                model.addElement("Patarra");
                model.addElement("San Cristobal");
                model.addElement("Rosario");
                model.addElement("Damas");
                model.addElement("San Rafael Abajo");
                model.addElement("Gravillas");
                model.addElement("Los Guido");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Puriscal":
                model.addElement("Santiago");
                model.addElement("Mercedes Sur");
                model.addElement("Barbacoas");
                model.addElement("Grifo Alto");
                model.addElement("San Rafael");
                model.addElement("Candelaria");
                model.addElement("Desamparaditos");
                model.addElement("San Antonio");
                model.addElement("Chires");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Tarrazú":
                model.addElement("San Marcos");
                model.addElement("San Lorenzo");
                model.addElement("San Carlos");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Aserrí":
                model.addElement("Aserri");
                model.addElement("Legua");
                model.addElement("Monterrey");
                model.addElement("Saltrillos");
                model.addElement("San Gabriel");
                model.addElement("Tarbaca");
                model.addElement("Vuelta de Jorco");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Mora":
                model.addElement("Ciudad Colon");
                model.addElement("Guayabo");
                model.addElement("Jaris");
                model.addElement("Picares");
                model.addElement("Piedras Negras");
                model.addElement("Tabarcia");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Goicoechea":
                model.addElement("Calle Blancos");
                model.addElement("Guadalupe");
                model.addElement("Ipis");
                model.addElement("Mata de Platano");
                model.addElement("Purral");
                model.addElement("Rancho Redondo");
                model.addElement("San Francisco");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Santa Ana":
                model.addElement("Brasil");
                model.addElement("Piedades");
                model.addElement("Pozos");
                model.addElement("Salitral");
                model.addElement("Santa Ana");
                model.addElement("Uruca");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Alajuelita":
                model.addElement("Alajuelita");
                model.addElement("Concepcion");
                model.addElement("San Antonio");
                model.addElement("San Felipe");
                model.addElement("San Josecito");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Vásquez de Coronado":
                model.addElement("Cascajal");
                model.addElement("Dulce Nombre de Jesus");
                model.addElement("Patalillo");
                model.addElement("San Isidro");
                model.addElement("San Rafael");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Acosta":
                model.addElement("Cangrejal");
                model.addElement("Guaitil");
                model.addElement("Palmichal");
                model.addElement("Sabanillas");
                model.addElement("San Ignacio");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Tibás":
                model.addElement("Anselmo Llorente");
                model.addElement("Cinco Esquinas");
                model.addElement("Colina");
                model.addElement("Leon XIII");
                model.addElement("San Juan");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Moravia":
                model.addElement("San Jeronimo");
                model.addElement("San Vicente");
                model.addElement("Trinidad");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Montes de Oca":
                model.addElement("Mercedes");
                model.addElement("Sabanilla");
                model.addElement("San Pedro");
                model.addElement("San Rafael");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Turrubares":
                model.addElement("Carara");
                model.addElement("San Juan de Mata");
                model.addElement("San Luis");
                model.addElement("San Pablo");
                model.addElement("San Pedro");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Dota":
                model.addElement("Copey");
                model.addElement("Jardin");
                model.addElement("Santa Maria");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Curridabat":
                model.addElement("Curridabat");
                model.addElement("Granadilla");
                model.addElement("Sanchez");
                model.addElement("Tirrases");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Pérez Zeledón":
                model.addElement("San Isidro de El General");
                model.addElement("Baru");
                model.addElement("Cajon");
                model.addElement("Daniel Flores");
                model.addElement("El General");
                model.addElement("La Amistad");
                model.addElement("Paramo");
                model.addElement("Pejibaye");
                model.addElement("Platanares");
                model.addElement("Rio Nuevo");
                model.addElement("Rivas");
                model.addElement("San Pedro");

                registerView.cmbDistrito.setModel(model);
                break;

            case "León Cortés":
                model.addElement("San Pablo");
                model.addElement("San Andres");
                model.addElement("Llano Bonito");
                model.addElement("San Isidro");
                model.addElement("Santa Cruz");
                model.addElement("San Antonio");

                registerView.cmbDistrito.setModel(model);
                break;

            //Alajuela
            case "Alajuela":
                model.addElement("Alajuela");
                model.addElement("Carrizal");
                model.addElement("Desamparados");
                model.addElement("Garita");
                model.addElement("Guacima");
                model.addElement("Rio Segundo");
                model.addElement("Sabanilla");
                model.addElement("San Antonio");
                model.addElement("San Isidro");
                model.addElement("San Jose");
                model.addElement("San Rafael");
                model.addElement("Sarapiqui");
                model.addElement("Tambor");
                model.addElement("Turrucares");

                registerView.cmbDistrito.setModel(model);
                break;

            case "San Ramón":
                model.addElement("San Ramón");
                model.addElement("Santigo");
                model.addElement("Piedades Norte");
                model.addElement("Piedades Sur");
                model.addElement("San Rafael");
                model.addElement("San Isidro");
                model.addElement("Angeles");
                model.addElement("Alfaro");
                model.addElement("Volio");
                model.addElement("Concepcion");
                model.addElement("Zapotal");
                model.addElement("Peñas Blancas");
                model.addElement("San Lorenzo");
                model.addElement("");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Grecia":
                model.addElement("Bolivar");
                model.addElement("Grecia");
                model.addElement("Puente de Piedra");
                model.addElement("San Isidro");
                model.addElement("San Jose");
                model.addElement("San Roque");
                model.addElement("Tacares");

                registerView.cmbDistrito.setModel(model);
                break;

            case "San Mateo":
                model.addElement("San Mateo");
                model.addElement("Desmonte");
                model.addElement("Jesus Maria");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Atenas":
                model.addElement("Atenas");
                model.addElement("Concepcion");
                model.addElement("Escobal");
                model.addElement("Jesús");
                model.addElement("Mercedes");
                model.addElement("San Isidro");
                model.addElement("San José");
                model.addElement("Santa Eulalia");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Naranjo":
                model.addElement("Cirri Sur");
                model.addElement("El Rosario");
                model.addElement("Naranjo");
                model.addElement("Palmitos");
                model.addElement("San Jerónimo");
                model.addElement("San José");
                model.addElement("San Juan");
                model.addElement("San Miguel");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Palmares":
                model.addElement("Buenos Aires");
                model.addElement("Candelaria");
                model.addElement("Esquipulas");
                model.addElement("La Granja");
                model.addElement("Palmares");
                model.addElement("Santiago");
                model.addElement("Zaragoza");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Poás":
                model.addElement("Carrillos");
                model.addElement("Sabana Redonda");
                model.addElement("San Juan");
                model.addElement("San Pedro");
                model.addElement("San Rafael");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Orotina":
                model.addElement("Coyolar");
                model.addElement("Hacienda Vieja");
                model.addElement("La Ceiba");
                model.addElement("Mastate");
                model.addElement("Orotina");

                registerView.cmbDistrito.setModel(model);
                break;

            case "San Carlos":
                model.addElement("Aguas Zarcas");
                model.addElement("Buenavista");
                model.addElement("Cutris");
                model.addElement("Florencio");
                model.addElement("La Fortuna");
                model.addElement("La Palmera");
                model.addElement("La Tigra");
                model.addElement("Monterrey");
                model.addElement("Pital");
                model.addElement("Pocosol");
                model.addElement("Quesada");
                model.addElement("Venado");
                model.addElement("Venecia");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Zarcero":
                model.addElement("Brisas");
                model.addElement("Guadalupe");
                model.addElement("Laguna");
                model.addElement("Palmira");
                model.addElement("Tapezco");
                model.addElement("Zapote");
                model.addElement("Zarcero");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Sarchí":
                model.addElement("Sarchí Norte");
                model.addElement("Sarchí Sur");
                model.addElement("Toro Amarrillo");
                model.addElement("San Pedro");
                model.addElement("Rodríguez");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Upala":
                model.addElement("Aguas Claras");
                model.addElement("Bijagua");
                model.addElement("Delicias");
                model.addElement("Dos Rios");
                model.addElement("San José");
                model.addElement("Upala");
                model.addElement("Yolillal");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Los Chiles":
                model.addElement("Caño Negro");
                model.addElement("El Amparo");
                model.addElement("Los Chiles");
                model.addElement("San Jorge");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Guatuso":
                model.addElement("Buenavista");
                model.addElement("Cote Katira");
                model.addElement("San Rafael");

                registerView.cmbDistrito.setModel(model);
                break;
            //Cartago

            case "Cartago":
                model.addElement("Agua Caliente");
                model.addElement("Carmen");
                model.addElement("Corralillo");
                model.addElement("Dulce Nombre");
                model.addElement("Guadalupe");
                model.addElement("Llano Grande");
                model.addElement("Occidental");
                model.addElement("Oriental");
                model.addElement("Quebradilla");
                model.addElement("San Nicolas");
                model.addElement("Tierra Blanca");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Paraíso":
                model.addElement("Cachí");
                model.addElement("Llanos de San Lucía");
                model.addElement("Orosí");
                model.addElement("Paraíso");
                model.addElement("Santiago de Paraíso");

                registerView.cmbDistrito.setModel(model);
                break;

            case "La Unión":
                model.addElement("Concepcion");
                model.addElement("Dulce Nombre");
                model.addElement("Rio Azul");
                model.addElement("San Diego");
                model.addElement("San Juan");
                model.addElement("San Rafael");
                model.addElement("San Ramon");
                model.addElement("Tres Rios");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Jiménez":
                model.addElement("Juan Viñas");
                model.addElement("Pejibaye");
                model.addElement("Tucurrique");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Turrialba":
                model.addElement("Chirripó");
                model.addElement("La Isabel");
                model.addElement("La Suiza");
                model.addElement("Pavones");
                model.addElement("Peralta");
                model.addElement("Santa Cruz");
                model.addElement("Santa Rosa");
                model.addElement("Santa Teresita");
                model.addElement("Tayutic");
                model.addElement("Tres Equis");
                model.addElement("Tuis");
                model.addElement("Turrialba");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Alvarado":
                model.addElement("Capellades");
                model.addElement("Cervantes");
                model.addElement("Pacayas");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Oreamundo":
                model.addElement("Cipreses");
                model.addElement("Cot");
                model.addElement("Potrero Cerrado");
                model.addElement("San Rafael");
                model.addElement("Santa Rosa");

                registerView.cmbDistrito.setModel(model);
                break;

            case "El Guarco":
                model.addElement("Patio Agua");
                model.addElement("San Isidro");
                model.addElement("Tejar");
                model.addElement("Tobosi");

                registerView.cmbDistrito.setModel(model);
                break;

            //Heredia
            case "Heredia":
                model.addElement("Heredia");
                model.addElement("Mercedes");
                model.addElement("San Franciso");
                model.addElement("Ulloa");
                model.addElement("Varablanca");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Barva":
                model.addElement("Barva");
                model.addElement("San José de la Montaña");
                model.addElement("San Pablo");
                model.addElement("San Pedro");
                model.addElement("San Roque");
                model.addElement("Santa Lucia");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Santo Domingo":
                model.addElement("Pará");
                model.addElement("Paracito");
                model.addElement("San Miguel");
                model.addElement("San Vicente");
                model.addElement("Santa Rosa");
                model.addElement("Santo Domingo");
                model.addElement("San Tomás");
                model.addElement("Tures");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Santa Bárbara":
                model.addElement("Jesús");
                model.addElement("Purabá");
                model.addElement("San Juan");
                model.addElement("San Pedro");
                model.addElement("Santa Bárbara");
                model.addElement("Santo Domingo");

                registerView.cmbDistrito.setModel(model);
                break;

            case "San Rafael":
                model.addElement("Ángeles");
                model.addElement("Concepcion");
                model.addElement("San Josecito");
                model.addElement("San Rafael");
                model.addElement("Santiago");

                registerView.cmbDistrito.setModel(model);
                break;

            case "San Isidro":
                model.addElement("Concepcion");
                model.addElement("San Francisco");
                model.addElement("San Isidro");
                model.addElement("San José");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Belén":
                model.addElement("La Asuncion");
                model.addElement("La Ribera");
                model.addElement("San Antonio");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Flores":
                model.addElement("Barrantes");
                model.addElement("Llorente");
                model.addElement("San Joaquin");

                registerView.cmbDistrito.setModel(model);
                break;

            case "San Pablo":
                model.addElement("Rincon de Sabanilla");
                model.addElement("San Pablo");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Sarapiquí":
                model.addElement("Cureña");
                model.addElement("La Virgen");
                model.addElement("Las Horquetas");
                model.addElement("Llanuras del Gaspar");
                model.addElement("Puerto Viejo");

                registerView.cmbDistrito.setModel(model);
                break;

            //Guanacaste
            case "Liberia":
                model.addElement("Cañas Dulces");
                model.addElement("Curubande");
                model.addElement("Liberia");
                model.addElement("Mayorga");
                model.addElement("Nacascolo");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Nicoya":
                model.addElement("Belén de Nosarita");
                model.addElement("Mansión");
                model.addElement("Nicoya");
                model.addElement("Nosara");
                model.addElement("Quebrada Honda");
                model.addElement("Sámara");
                model.addElement("San Antonio");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Santa Cruz":
                model.addElement("Bolsón");
                model.addElement("Cabo Velas");
                model.addElement("Cartagena");
                model.addElement("Cuajiniquil");
                model.addElement("Diriá");
                model.addElement("Santa Cruz");
                model.addElement("Tamarindo");
                model.addElement("Tempate");
                model.addElement("Veintisiete de Abril");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Bagaces":
                model.addElement("Bagaces");
                model.addElement("La Fortuna");
                model.addElement("Mogote");
                model.addElement("Río Naranjo");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Carrillo":
                model.addElement("Belén");
                model.addElement("Filadelfia");
                model.addElement("Palmira");
                model.addElement("Sardinal");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Cañas":
                model.addElement("Bebedero");
                model.addElement("Cañas");
                model.addElement("Palmira");
                model.addElement("Porozal");
                model.addElement("San Miguel");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Abangares":
                model.addElement("Colorado");
                model.addElement("Las Juntas");
                model.addElement("San Juan");
                model.addElement("Sierra");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Tilarán":
                model.addElement("Arenal");
                model.addElement("Libano");
                model.addElement("Quebrada Grande");
                model.addElement("Santa Rosa");
                model.addElement("Tierras Morenas");
                model.addElement("Tilarán");
                model.addElement("Tronadora");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Nandayure":
                model.addElement("Bejuco");
                model.addElement("Carmona");
                model.addElement("Porvenir");
                model.addElement("San Pablo");
                model.addElement("Santa Rita");
                model.addElement("Zapotal");

                registerView.cmbDistrito.setModel(model);
                break;

            case "La Cruz":
                model.addElement("La Cruz");
                model.addElement("La Garita");
                model.addElement("Santa Cecilia");
                model.addElement("Santa Elena");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Hojancha":
                model.addElement("Hojancha");
                model.addElement("Huacas");
                model.addElement("Monte Romo");
                model.addElement("Puerto Carrillo");

                registerView.cmbDistrito.setModel(model);
                break;

            //Puntarenas
            case "Puntarenas":
                model.addElement("Acapulco");
                model.addElement("Arancibia");
                model.addElement("Barranca");
                model.addElement("Chacarita");
                model.addElement("Chira");
                model.addElement("Chomes");
                model.addElement("Cóbano");
                model.addElement("El Roble");
                model.addElement("Guacimal");
                model.addElement("Isla del Coco");
                model.addElement("Lepanto");
                model.addElement("Manzanillo");
                model.addElement("Monteverde");
                model.addElement("Paquera");
                model.addElement("Pitahaya");
                model.addElement("Puntarenas");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Esparza":
                model.addElement("Espíritu Santo");
                model.addElement("Macacona");
                model.addElement("San Jeronimo");
                model.addElement("San Juan Grande");
                model.addElement("San Rafael");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Buenos Aires":
                model.addElement("Biolley");
                model.addElement("Boruca");
                model.addElement("Brunka");
                model.addElement("Buenos Aires");
                model.addElement("Chánguena");
                model.addElement("Colinas");
                model.addElement("Pilas");
                model.addElement("Potrero Grande");
                model.addElement("Volcán");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Montes de Oro":
                model.addElement("La Unión");
                model.addElement("Miramar");
                model.addElement("San Isidro");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Osa":
                model.addElement("Bahia Ballena");
                model.addElement("Palmar");
                model.addElement("Piedras Blancas");
                model.addElement("Puerto Cortés");
                model.addElement("Sierpe");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Quepos":
                model.addElement("Quepos");
                model.addElement("Naranjito");
                model.addElement("Savege");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Golfito":
                model.addElement("Golfito");
                model.addElement("Guayara");
                model.addElement("Pavón");
                model.addElement("Puerto Jiménez");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Coto Brus":
                model.addElement("Aguabuena");
                model.addElement("Limoncito");
                model.addElement("Pittier");
                model.addElement("Sabalito");
                model.addElement("San Vito");
                model.addElement("Gutiérrez Brown");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Parrita":
                model.addElement("Parrita");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Corredores":
                model.addElement("Corredores");
                model.addElement("La Cuesta");
                model.addElement("Laurel");
                model.addElement("Paso Canoas");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Garabito":
                model.addElement("Jacó");
                model.addElement("Tárcoles");

                registerView.cmbDistrito.setModel(model);
                break;

            //Limón
            case "Limón":
                model.addElement("Limón");
                model.addElement("Matama");
                model.addElement("Río Blanco");
                model.addElement("Valle La Estrella");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Pococí":
                model.addElement("Cariari");
                model.addElement("Colorado");
                model.addElement("Guápiles");
                model.addElement("Jiménez");
                model.addElement("Rita");
                model.addElement("Roxana");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Siquirres":
                model.addElement("La Alegría");
                model.addElement("Cairo");
                model.addElement("Florida");
                model.addElement("Germania");
                model.addElement("Pacuarito");
                model.addElement("Siquirres");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Talamanca":
                model.addElement("Bratsi");
                model.addElement("Cahuita");
                model.addElement("Sixaola");
                model.addElement("Telire");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Matina":
                model.addElement("Batán");
                model.addElement("Carrandi");
                model.addElement("Matina");

                registerView.cmbDistrito.setModel(model);
                break;

            case "Guácimo":
                model.addElement("Duacarí");
                model.addElement("Guácimo");
                model.addElement("Mercedes");
                model.addElement("Pocora");
                model.addElement("Río Jiménez");

                registerView.cmbDistrito.setModel(model);
                break;
        }

    }

    public boolean verificarEspacios() {

        if (registerView.txtcedula.getText().isEmpty()) {
            JOptionPane.showMessageDialog(registerView, "Falta campo Nombre");
            registerView.txtcedula.requestFocus(true);
            return true;
        } else if (registerView.txtnombre.getText().isEmpty()) {
            JOptionPane.showMessageDialog(registerView, "Falta campo Apellido Paterno");
            registerView.txtnombre.requestFocus(true);
            return true;
        } else if (registerView.txtape1.getText().isEmpty()) {
            JOptionPane.showMessageDialog(registerView, "Falta campo Apellido Materno");
            registerView.txtape1.requestFocus(true);
            return true;
        } else if (registerView.txtape2.getText().isEmpty()) {
            JOptionPane.showMessageDialog(registerView, "Falta campo Fecha");
            registerView.txtape2.requestFocus(true);
            return true;
        } else if (registerView.txttelefono.getText().isEmpty()) {
            JOptionPane.showMessageDialog(registerView, "Falta campo Telefono");
            registerView.txttelefono.requestFocus(true);
            return true;
        } else if (registerView.txtdireccion.getText().isEmpty()) {
            JOptionPane.showMessageDialog(registerView, "Falta campo Direccion");
            registerView.txtdireccion.requestFocus(true);
            return true;
        } else if (registerView.txtusuario.getText().isEmpty()) {
            JOptionPane.showMessageDialog(registerView, "Falta campo Usuario");
            registerView.txtusuario.requestFocus(true);
            return true;
        } else if (registerView.txtpass.getText().isEmpty()) {
            JOptionPane.showMessageDialog(registerView, "Falta campo Contraseña");
            registerView.txtpass.requestFocus(true);
            return true;
        }

        return false;
    }
}
