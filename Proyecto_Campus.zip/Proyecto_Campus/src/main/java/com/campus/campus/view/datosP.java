
package com.campus.campus.view;
import java.sql.Connection;
import java.sql.DriverManager;


public class datosP {
    
     Connection conectar=null;
    public Connection conexion(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conectar=DriverManager.getConnection("jdbc:mysql://80.211.39.128:3310/campus","user1","userdb");
        } catch (Exception e) {
            System.out.print(e.getMessage());
        }
        return conectar;
    }
    
    
}