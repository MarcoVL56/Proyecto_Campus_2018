
package com.campus.campus.entity;

/**
 *
 * @author Adriel
 */
public class usuario {
    int id;
    String nombre, clave;
    int fk_Id_Tipo;

    public usuario() {
    }

    public usuario(int id, String nombre, String clave, int fk_Id_Tipo) {
        this.id = id;
        this.nombre = nombre;
        this.clave = clave;
        this.fk_Id_Tipo = fk_Id_Tipo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

    public int getFk_Id_Tipo() {
        return fk_Id_Tipo;
    }

    public void setFk_Id_Tipo(int fk_Id_Tipo) {
        this.fk_Id_Tipo = fk_Id_Tipo;
    }
    
    
}
