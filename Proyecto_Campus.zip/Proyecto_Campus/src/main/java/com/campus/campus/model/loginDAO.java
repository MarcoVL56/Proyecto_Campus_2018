/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.campus.campus.model;

import com.campus.campus.entity.estudiante;
import com.campus.campus.entity.usuario;
import com.campus.campus.view.JFLogin;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author Adriel
 */
public class loginDAO {

    private JFLogin loginView;
    connection con;
    usuario usu = new usuario();

    public loginDAO() {
        con = new connection();
    }
    
    public usuario verificaUsuario(String usuario, String contraseña, JFLogin loginView) {
        estudiante estudiante = null;
        this.loginView = loginView;
        this.loginView.lblErrorUsu.setText("");
        this.loginView.lblErrorContra.setText("");
        String error = "", errorUsu = "", errorContra = "";

        if (!usuario.isEmpty()) {

            if (!contraseña.isEmpty()) {
                con.connect();
                Connection accesoDB = con.getConnection();

                try {
                    PreparedStatement ps = accesoDB.prepareStatement("SELECT * FROM usuario WHERE Nombre=?");
                    ps.setString(1, usuario);
                    ResultSet rs = ps.executeQuery();
                    if (rs.next()) {
                        usuario usu = new usuario();
                        ps = accesoDB.prepareStatement("SELECT * FROM usuario WHERE Clave=?");
                        ps.setString(1, contraseña);
                        rs = ps.executeQuery();
                        if (rs.next()) {
                            ps = accesoDB.prepareStatement("SELECT * FROM usuario WHERE Nombre=? AND Clave=?");
                            ps.setString(1, usuario);
                            ps.setString(2, contraseña);
                            rs = ps.executeQuery();
                            if (rs.next()) {
                                usu.setId(Integer.parseInt(rs.getString(1)));
                                usu.setNombre(rs.getString(2));
                                usu.setClave(rs.getString(3));
                                usu.setFk_Id_Tipo(Integer.parseInt(rs.getString(4)));
                                con.closeConnection();
                                return usu;
                            }
                        } else {
                            errorContra = "Contraseña incorrecta";
                        }
                    } else {
                        errorUsu = "Usuario incorrecto";
                    }
                } catch (Exception e) {
                }
            } else {
                error = "Debe rellenar el campo de contraseña";
                this.loginView.lblErrorContra.setText(error);
            }
        } else {
            error = "Debe rellenar el campo de usuario";
            this.loginView.lblErrorUsu.setText(error);
            if (contraseña.isEmpty()) {
                error = "Debe rellenar el campo de contraseña";
                this.loginView.lblErrorContra.setText(error);
            }
        }

        if (!errorUsu.isEmpty()) {
            this.loginView.lblErrorUsu.setText(errorUsu);
            usuario p = null;
            con.closeConnection();
            return p;
        } else if (!errorContra.isEmpty()) {
            this.loginView.lblErrorContra.setText(errorContra);
            usuario p = null;
            con.closeConnection();
            return p;
        }
        con.closeConnection();
        return usu;
    }
}
