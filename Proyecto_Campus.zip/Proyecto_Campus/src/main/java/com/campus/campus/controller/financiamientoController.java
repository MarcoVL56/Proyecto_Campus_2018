package com.campus.campus.controller;


import com.campus.campus.entity.estudiante;
import com.campus.campus.model.connection;
import com.campus.campus.view.JFFinanciamiento;
import java.awt.event.ActionEvent;

import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;

import java.util.Date;

public class financiamientoController implements ActionListener {

    public JFFinanciamiento FView = new JFFinanciamiento();
    connection con;

    public financiamientoController() {

        fecha();
        con = new connection();
        this.FView.setVisible(true);
        this.FView.setLocationRelativeTo(null);

        this.FView.btnPagarFinanc.addActionListener(this);
        this.FView.btnVer.addActionListener(this);
        this.FView.btnAceptar.addActionListener(this);

       

    }

    public void iniciar() {
        FView.setTitle("Financiamiento");
        FView.setLocationRelativeTo(null);

    }
      

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == FView.btnVer) {
            totalfinanciado();

        }
        

        if (e.getSource() == FView.btnAceptar) {
            Cuota();
        }
        if (e.getSource() == FView.btnPagarFinanc) {

            pagarCuota();

        }

    }

    public void fecha() {

        java.util.Date myDate = new Date();
        FView.lbFecha.setText(new SimpleDateFormat("dd-MM-yyyy").format(myDate));

    }

    public void totalfinanciado() {
        con.connect();
        Connection accesoDB = con.getConnection();

        try {

            int cedu = Integer.parseInt(FView.txtCedula.getText());

            PreparedStatement ps = accesoDB.prepareStatement("SELECT factura.* FROM factura,estudiante WHERE estudiante.idEstudiante=" + cedu + " AND factura.Fk_idEstudiante=estudiante.idEstudiante");
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {//muesta el total fn

                int fact = rs.getInt("id_Factura");

                PreparedStatement sp = accesoDB.prepareStatement("SELECT financiamiento.* FROM financiamiento,factura WHERE factura.id_Factura=" + fact + " AND financiamiento.Fk_id_factura=factura.id_Factura");
                ResultSet sr = sp.executeQuery();

                FView.txtTotal.setText(String.valueOf(rs.getInt("montoTotal")));

                if (sr.next()) {//muestra las cuotas

                    int mTotal = (rs.getInt("montoTotal"));

                    int mCuota = sr.getInt("montoPorCuota");
                    FView.txtTotalFinanciado.setText("₡" + mTotal);
                    FView.txtTotalPorCuota.setText("₡" + mCuota);
                    FView.txtPagoFinanc.setText("₡" + mCuota);

                } else {
                    FView.txtTotalFinanciado.setText("Vacio");
                    FView.txtTotalPorCuota.setText("Vacio");
                }
            }

        } catch (Exception e) {

            System.out.println("Error: " + e);
        }
    }

    public void Cuota() {

        con.connect();
        Connection accesoDB = con.getConnection();

        try {

            int cedu = Integer.parseInt(FView.txtCedula.getText());

            PreparedStatement ps = accesoDB.prepareStatement("SELECT factura.* FROM factura,estudiante WHERE estudiante.idEstudiante=" + cedu + " AND factura.Fk_idEstudiante=estudiante.idEstudiante");
            ResultSet rs = ps.executeQuery();

            //   if(cedu)
            if (rs.next()) {//muesta el total fn

                int mTotal = rs.getInt("montoTotal");
                int mTF = (mTotal + 7500);
                int mCuota = (mTF / 3);
                int fact = rs.getInt("id_Factura");

                PreparedStatement tot = accesoDB.prepareStatement("UPDATE factura SET montoTotal='" + mTF + "' WHERE factura.Fk_idEstudiante='" + cedu + "'");
                tot.executeUpdate();

                FView.txtTotal.setText("" + mTF);

                PreparedStatement pst = accesoDB.prepareStatement("INSERT INTO financiamiento  VALUES (?,?,?,?)");

                pst.setInt(1, 0);
                pst.setInt(2, 3);
                pst.setInt(3, mCuota);
                pst.setInt(4, fact);
                pst.executeUpdate();

                FView.txtTotalFinanciado.setText("₡" + mTotal);
                FView.txtTotalPorCuota.setText("₡ " + mCuota);
                FView.txtPagoFinanc.setText(("₡ " + mCuota));

                JOptionPane.showMessageDialog(null, "Financiamiento Exitoso");

            } else {
                JOptionPane.showMessageDialog(null, "Error");

            }

        } catch (Exception e) {

            System.out.println("Error: " + e);
        }

    }

    public void pagarCuota() {
        con.connect();
        Connection accesoDB = con.getConnection();

        try {

            int cedu = Integer.parseInt(FView.txtCedula.getText());

            PreparedStatement ps = accesoDB.prepareStatement("SELECT factura.* FROM factura,estudiante WHERE estudiante.idEstudiante=" + cedu + " AND factura.Fk_idEstudiante=estudiante.idEstudiante");
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                int fact = rs.getInt("id_Factura");
                PreparedStatement sp = accesoDB.prepareStatement("SELECT financiamiento.* FROM financiamiento,factura WHERE factura.id_Factura=" + fact + " AND financiamiento.Fk_id_factura=factura.id_Factura");
                ResultSet sr = sp.executeQuery();

                if (sr.next()) {
                    int ncu = sr.getInt("cantidadDeCuotas");
                    int mTotal = rs.getInt("montoTotal");

                    if ((ncu > 0) || mTotal > 0) {
                        int fCuota = sr.getInt("montoPorCuota");

                        int pago = (mTotal - fCuota);
                        PreparedStatement pst = accesoDB.prepareStatement("UPDATE factura SET montoTotal='" + pago + "' WHERE factura.Fk_idEstudiante='" + cedu + "'");
                        pst.executeUpdate();

                        ncu = ncu - 1;

                        PreparedStatement nc = accesoDB.prepareStatement("UPDATE financiamiento SET cantidadDeCuotas='" + ncu + "' WHERE financiamiento.Fk_id_factura='" + fact + "'");
                        nc.executeUpdate();

                        JOptionPane.showMessageDialog(null, "Pago Exitoso");

                    } else if (ncu <= 0) {
                        JOptionPane.showMessageDialog(null, "Financiamiento cancelado");
                        PreparedStatement pst = accesoDB.prepareStatement("UPDATE factura SET montoTotal='" + 0 + "' WHERE factura.Fk_idEstudiante='" + cedu + "'");
                        pst.executeUpdate();
                        PreparedStatement nc = accesoDB.prepareStatement("UPDATE financiamiento SET cantidadDeCuotas='" + 0 + "' WHERE financiamiento.Fk_id_factura='" + fact + "'");
                        nc.executeUpdate();
                        FView.txtTotal.setText("₡" + 0);
                        FView.txtTotalFinanciado.setText("₡" + 0);
                        FView.txtTotalPorCuota.setText("₡" + 0);
                        FView.txtPagoFinanc.setText("₡" + 0);

                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Error de pago");

                }

            }

        } catch (Exception e) {

            System.out.println("Error: " + e);
        }
    }

    public void facturaFn() {
        JOptionPane.showMessageDialog(null, "");

    }

}
