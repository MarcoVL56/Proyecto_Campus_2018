/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.campus.campus.controller;

import com.campus.campus.entity.estudiante;
import com.campus.campus.entity.usuario;
import com.campus.campus.model.loginDAO;
import com.campus.campus.view.JFLogin;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;

/**
 *
 * @author Adriel
 */
public class loginController implements MouseListener {

    JFLogin loginView = new JFLogin();
    usuario usu = new usuario();
    loginDAO loginDAO = new loginDAO();

    public loginController() {
        this.loginView.setVisible(true);
        this.loginView.setLocationRelativeTo(null);
        this.loginView = loginView;
        this.loginView.lblErrorUsu.setText("");
        this.loginView.lblErrorContra.setText("");
//        this.loginView.btnIniciar.addActionListener(this);
    }

    

    @Override
    public void mouseClicked(MouseEvent me) {
//        if (me.getSource() == loginView.) {
//            String usuario = String.valueOf(loginView.txtUsuario.getText());
//            String contra = String.valueOf(loginView.txtContraseña.getText());
//            usu = loginDAO.verificaUsuario(usuario, contra, loginView);
//            if (usu != null) {
//                JFMainMenu menuView = new JFMainMenu();
//                menuView.setVisible(true);
//                menuView.setLocationRelativeTo(null);
//                loginView.dispose();
//            }
//        }
    }

    @Override
    public void mousePressed(MouseEvent me) {
        
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        
    }

    @Override
    public void mouseExited(MouseEvent me) {
      
    }
}
