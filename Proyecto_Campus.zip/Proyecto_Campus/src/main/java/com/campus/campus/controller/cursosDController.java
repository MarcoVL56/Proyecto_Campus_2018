package com.campus.campus.controller;

import com.campus.campus.entity.estadoEstduante;
import com.campus.campus.entity.estudiante;
import com.campus.campus.model.connection;
import com.campus.campus.view.CusosDisp;
import com.campus.campus.view.IngresoAMatricula;
import java.awt.List;
import java.awt.MenuItem;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import javax.swing.JMenuItem;
import javax.swing.JPopupMenu;

import javax.swing.table.DefaultTableModel;


public class cursosDController implements ActionListener {

    connection con;

    CusosDisp cD = new CusosDisp();
    IngresoAMatricula iM = new IngresoAMatricula();
    estadoEstduante eE = new estadoEstduante();

    int carrera;
    int estudiante;
    int cantidaC;
    int curso;

    public cursosDController() {

        this.cD.setVisible(true);
        this.cD.setLocationRelativeTo(null);
        this.cD.btnPrematricular.addActionListener(this);
        this.cD.btnVolverAMenu.addActionListener(this);
        this.cD.btnMostrarCursos.addActionListener(this);
        this.cD.btnMotrarMa.addActionListener(this);

        this.iM.setLocationRelativeTo(null);

        CusosDisp cD = new CusosDisp();

        con = new connection();

    }

    public void iniciar() {
        Estudiante();
        carreras();

        popupTable();

        mostrarCuatri1("");
        mostrarCuatri2("");

    }

    public void carreras() {
        cD.lblCarrera.setText("" + carrera);
        if (carrera == 1) {

            cD.lblCarrera.setText("Ingenieria en Sistemas");

        }
        if (carrera == 2) {

            cD.lblCarrera.setText("Ingenieria Civil");

        }
        if (carrera == 3) {

            cD.lblCarrera.setText("Ingenieria Industrial");

        }
        if (carrera == 4) {

            cD.lblCarrera.setText("Administracion");

        }
    }

    public void Estudiante() {
        cD.lblEstudiante.setText("" + estudiante);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {

     
        if (ae.getSource() == cD.btnVolverAMenu) {
            ingresoController iG = new ingresoController();
            cD.dispose();
        }

        if (ae.getSource() == cD.btnMostrarCursos) {

            cantidadCursos();
            mostrarCuatriDisponibles("");

        }

        if (ae.getSource() == cD.btnMotrarMa) {

            cantidadCursos();
            mostrarCuatriMatriculado("");

        }

    }

    public void cantidadCursos() {
        setCantidaC(cD.cmbCantidadC.getSelectedIndex() + 2);
    }

    void mostrarCuatriDisponibles(String valor) {
        con.connect();
        Connection cn = con.getConnection();

        DefaultTableModel modelo = new DefaultTableModel();

        modelo.addColumn("Código curso");
        modelo.addColumn("Estado");

        cD.tblcDisponibles.setModel(modelo);
        String sql = "";
        if (valor.equals("")) {

            sql = "Select * From estadoestudiante where Fk_idEstudiante='" + estudiante + "' AND Estado='Disponible' ORDER BY Fk_idCurso ASC LIMIT " + cantidaC + "";
        }

        String[] datos = new String[4];
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {

                datos[0] = rs.getString(4);
                datos[1] = rs.getString(2);

                modelo.addRow(datos);
            }
            cD.tblcDisponibles.setModel(modelo);
            cD.txtCantidad.setText("" + cD.tblcDisponibles.getRowCount());
        } catch (SQLException ex) {
            System.out.println(ex);

        }
    }

    void mostrarCuatriMatriculado(String valor) {
        con.connect();
        Connection cn = con.getConnection();

        DefaultTableModel modelo = new DefaultTableModel();

        modelo.addColumn("Código curso");
        modelo.addColumn("Estado");

        cD.tblMatricular.setModel(modelo);
        String sql = "";
        if (valor.equals("")) {

            sql = "Select * From estadoestudiante where Fk_idEstudiante='" + estudiante + "' AND Estado='Matriculada' ORDER BY Fk_idCurso ASC LIMIT " + cantidaC + "";
        }

        String[] datos = new String[4];
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {

                datos[0] = rs.getString(4);
                datos[1] = rs.getString(2);

                modelo.addRow(datos);
            }
            cD.tblMatricular.setModel(modelo);
            cD.txtCantidad.setText("" + cD.tblMatricular.getRowCount());
        } catch (SQLException ex) {
            System.out.println(ex);

        }
    }

    void mostrarCuatri1(String valor) {
        con.connect();
        Connection cn = con.getConnection();

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Codigo");
        modelo.addColumn("Curso");
        modelo.addColumn("Creditos");
        modelo.addColumn("Precio");

        cD.tblCuatri1.setModel(modelo);
        String sql = "";
        if (valor.equals("")) {
            sql = "Select * From curso where Cuatrimestre=1 AND Fk_idCarrera='" + carrera + "'";

        }

        String[] datos = new String[4];
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {

                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(5);

                modelo.addRow(datos);
            }
            cD.tblCuatri1.setModel(modelo);
        } catch (SQLException ex) {
            System.out.println(ex);

        }
    }

    void mostrarCuatri2(String valor) {
        con.connect();
        Connection cn = con.getConnection();

        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("Codigo");
        modelo.addColumn("Curso");
        modelo.addColumn("Creditos");
        modelo.addColumn("Precio");

        cD.tblCuatri2.setModel(modelo);
        String sql = "";
        if (valor.equals("")) {
            sql = "Select * From curso where Cuatrimestre=2 AND Fk_idCarrera='" + carrera + "'";

        }

        String[] datos = new String[4];
        try {
            Statement st = cn.createStatement();
            ResultSet rs = st.executeQuery(sql);
            while (rs.next()) {

                datos[0] = rs.getString(1);
                datos[1] = rs.getString(2);
                datos[2] = rs.getString(3);
                datos[3] = rs.getString(5);

                modelo.addRow(datos);
            }
            cD.tblCuatri2.setModel(modelo);
        } catch (SQLException ex) {
            System.out.println(ex);

        }
    }

    public void popupTable() {
        con.connect();
        Connection cn = con.getConnection();
        JPopupMenu popupMenu = new JPopupMenu();

        JMenuItem menuItem = new JMenuItem("No la quiero matricular");

        menuItem.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent ae) {

                int fila = cD.tblcDisponibles.getSelectedRow();

                cD.txtFila.setText((String.valueOf(cD.tblcDisponibles.getValueAt(fila, 0))));

                try {
                    PreparedStatement pst = cn.prepareStatement("UPDATE `estadoestudiante` SET `Estado` = 'Matriculada' WHERE `estadoestudiante`.`Fk_idEstudiante` = " + estudiante + " AND Fk_idCurso =" + cD.txtFila.getText() + "");
                    pst.executeUpdate();

                } catch (Exception e) {
                    System.out.print(e.getMessage());
                }

            }
        });
        popupMenu.add(menuItem);

        cD.tblcDisponibles.setComponentPopupMenu(popupMenu);

    }

    public void setCarrera(int carrera) {
        this.carrera = carrera;
    }

    public int getCarrera() {
        return carrera;
    }

    public void setCantidaC(int cantidaC) {
        this.cantidaC = cantidaC;
    }

    public void setEstudiante(int estudiante) {
        this.estudiante = estudiante;
    }

    public void setcD(CusosDisp cD) {
        this.cD = cD;
    }

    public void setCurso(int curso) {
        this.curso = curso;
    }

}
