package com.campus.campus.model;

import java.awt.Color;
import java.awt.Font;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberTickUnit;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.plot.XYPlot;
import org.jfree.chart.renderer.xy.XYLineAndShapeRenderer;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.xy.XYSeriesCollection;
import org.jfree.ui.RectangleEdge;
import org.jfree.ui.VerticalAlignment;

public class generarGrafica {

    private static Color COLOR_SERIE_1 = new Color(255, 128, 64);

    private static Color COLOR_SERIE_2 = new Color(28, 84, 140);

    private static Color COLOR_SERIE_3 = new Color(50, 50, 50);

    private static Color COLOR_SERIE_4 = new Color(255, 0, 0);

    private static Color COLOR_RECUADROS_GRAFICA = new Color(200, 200, 200);

    private static Color COLOR_FONDO_GRAFICA = Color.white;

    public JFreeChart crearGrafica(CategoryDataset dataset, String titulo,String egeX , String egeY) {

        final TextTitle title = new TextTitle(titulo);
        title.setFont(new Font("Arial Rounded MT", Font.BOLD, 20));
        title.setPosition(RectangleEdge.TOP);
        title.setVerticalAlignment(VerticalAlignment.BOTTOM);
        
        final JFreeChart chart = ChartFactory.createAreaChart(titulo, egeX, egeY,
                dataset,
                PlotOrientation.VERTICAL,
                true, // uso de leyenda
                false, // uso de tooltips  
                false // uso de urls
        );
        chart.setTitle(title);
        // color de fondo de la gráfica
        chart.setBackgroundPaint(COLOR_FONDO_GRAFICA);

        //////////////
        chart.setBackgroundPaint(Color.white);
        

        final CategoryPlot plot = chart.getCategoryPlot();
        plot.setForegroundAlpha(0.5f);

        plot.setBackgroundPaint(new Color(255, 255, 255));
        plot.setDomainGridlinesVisible(true);
        plot.setDomainGridlinePaint(COLOR_RECUADROS_GRAFICA);
        plot.setRangeGridlinesVisible(true);
        plot.setRangeGridlinePaint(COLOR_RECUADROS_GRAFICA);

        final CategoryAxis domainAxis = plot.getDomainAxis();
        domainAxis.setCategoryLabelPositions(CategoryLabelPositions.UP_45);
        domainAxis.setLowerMargin(0.0);
        domainAxis.setUpperMargin(0.0);
        domainAxis.addCategoryLabelToolTip("Type 1", "The first type.");
        domainAxis.addCategoryLabelToolTip("Type 2", "The second type.");
        domainAxis.addCategoryLabelToolTip("Type 3", "The third type.");

        final NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        rangeAxis.setLabelAngle(0 * Math.PI / 2.0);


        return chart;
    }

    // configuramos el contenido del gráfico (damos un color a las líneas que sirven de guía)
    private void configurarPlot(XYPlot plot) {
        plot.setDomainGridlinePaint(COLOR_RECUADROS_GRAFICA);
        plot.setRangeGridlinePaint(COLOR_RECUADROS_GRAFICA);
        plot.setBackgroundPaint(new Color(255, 255, 255));
    }

    // configuramos el eje X de la gráfica (se muestran números enteros y de uno en uno)
    private void configurarDomainAxis(NumberAxis domainAxis) {
        domainAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        domainAxis.setTickUnit(new NumberTickUnit(1));
    }

    // configuramos el eje y de la gráfica (números enteros de dos en dos y rango entre 120 y 135)
    private void configurarRangeAxis(NumberAxis rangeAxis) {
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        rangeAxis.setTickUnit(new NumberTickUnit(2));
    }

    // configuramos las líneas de las series (añadimos un círculo en los puntos y asignamos el color de cada serie)
    private void configurarRendered(XYLineAndShapeRenderer renderer) {
        renderer.setSeriesShapesVisible(0, true);
        renderer.setSeriesShapesVisible(1, true);
        renderer.setSeriesShapesVisible(2, true);
        renderer.setSeriesShapesVisible(3, true);
        renderer.setSeriesPaint(0, COLOR_SERIE_1);
        renderer.setSeriesPaint(1, COLOR_SERIE_2);
        renderer.setSeriesPaint(2, COLOR_SERIE_3);
        renderer.setSeriesPaint(3, COLOR_SERIE_4);
    }

}
