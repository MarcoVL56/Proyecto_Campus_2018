package com.campus.campus;

import com.campus.campus.controller.estadisticaController;

import com.campus.campus.controller.ingresoController;
import com.campus.campus.controller.loginController;
import com.campus.campus.controller.registerController;
import com.campus.campus.entity.estudiante;
import com.campus.campus.model.connection;
import com.campus.campus.view.IngresoAMatricula;
import com.campus.campus.view.JFMenu;
import java.sql.Connection;
import java.sql.SQLException;

public class Main {
    
    public static void main(String[] args) throws SQLException {
        // loginController lC = new loginController();

        //registerController c = new registerController();
        JFMenu c = new JFMenu();
        c.setVisible(true);
        
//        financiamientoController f = new financiamientoController();
//        f.setX(123456);
//        f.iniciar();
//        estadisticaController e = new estadisticaController();

    }
    
}
