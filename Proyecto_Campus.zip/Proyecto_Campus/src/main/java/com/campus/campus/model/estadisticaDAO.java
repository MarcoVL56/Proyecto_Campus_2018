package com.campus.campus.model;

import com.campus.campus.view.JFEstadistica;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class estadisticaDAO {

    connection con;
    JFEstadistica e = new JFEstadistica();
    int numero;

    public estadisticaDAO() {
        con = new connection();
    }

    public int datos() throws SQLException {
        con.connect();
        Connection accesoDB = con.getConnection();
        JOptionPane.showMessageDialog(null, "Aqui");
        PreparedStatement ps = accesoDB.prepareStatement("SELECT * FROM estudiante");
        ResultSet rs = ps.executeQuery();
        int total = 0;
        while (rs.next()) {
            //Obtienes la data que necesitas...
            total++;
            JOptionPane.showMessageDialog(null, "Total + "+total);
            
        }
        return total;
    }

    public double[][] generardatos() {
        final double[][] data = null;

        return data;
    }

}
