package com.campus.campus.model;

import com.campus.campus.entity.estudiante;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

/**
 *
 * @author Adriel
 */
//public class registroDAO {
//
//    connection con;
//    estudiante p;
//    
//
//    public void registro(estudiante estudiante) {
//        p=estudiante;
//        con.connect();
//        Connection accesoDB = con.getConnection();
//
//        try {
//            PreparedStatement ps = accesoDB.prepareStatement("INSERT INTO estudiante VALUES (?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?)");
//            ps.setInt(1, p.getIdEstudiante());
//            ps.setString(2, p.getNombre());
//            ps.setString(3, p.getApellidoPaterno());
//            ps.setString(4, p.getApellidoMaterno());
//            ps.setInt(5, p.getNumeroTelefonico());
//            ps.setString(6, p.getCorreo());
//            ps.setString(7, p.getDireccion());
//            ps.setString(8, p.getDistrito());
//            ps.setString(9, p.getCanton());
//            ps.setString(10, p.getProvincia());
//            ps.executeUpdate();
//
//            ps = accesoDB.prepareStatement("SELECT LAST_INSERT_ID()");
//
//            ResultSet rs = ps.executeQuery();
//
//            if (rs.next()) {
//                ps = accesoDB.prepareStatement("INSERT INTO Usuarios VALUES (?, ?)");
//                ps.setInt(1, p.getId_usuario());
//                ps.setInt(2, p.getClave());
//                ps.executeUpdate();
//            }
//
//        } catch (Exception e) {
//            System.out.println("ERROR----" + e);
//        }
//        con.closeConnection();
//        JOptionPane.showMessageDialog(null, "Registrado");
//    }

//}
