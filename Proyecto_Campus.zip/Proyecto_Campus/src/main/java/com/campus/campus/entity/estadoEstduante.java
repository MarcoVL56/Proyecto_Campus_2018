
package com.campus.campus.entity;


public class estadoEstduante {
    
    
    int idEstado;
    String Estado;
    int idEstududiante;
    int idCurso;

    public estadoEstduante(int idEstado, String Estado, int idEstududiante, int idCurso) {
        this.idEstado = idEstado;
        this.Estado = Estado;
        this.idEstududiante = idEstududiante;
        this.idCurso = idCurso;
    }

    public estadoEstduante() {
    }

 


    
    
    

    public int getIdEstado() {
        return idEstado;
    }

    public void setIdEstado(int idEstado) {
        this.idEstado = idEstado;
    }

    public String getEstado() {
        return Estado;
    }

    public void setEstado(String Estado) {
        this.Estado = Estado;
    }

    public int getIdEstududiante() {
        return idEstududiante;
    }

    public void setIdEstududiante(int idEstududiante) {
        this.idEstududiante = idEstududiante;
    }

    public int getIdCurso() {
        return idCurso;
    }

    public void setIdCurso(int idCurso) {
        this.idCurso = idCurso;
    }
            
    
    
}
