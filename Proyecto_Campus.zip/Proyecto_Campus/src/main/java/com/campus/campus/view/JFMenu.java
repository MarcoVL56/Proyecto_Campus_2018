/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.campus.campus.view;

import com.campus.campus.controller.financiamientoController;
import com.campus.campus.controller.ingresoController;

public class JFMenu extends javax.swing.JFrame {

    /**
     * Creates new form JFMenu
     */
    public JFMenu() {
        initComponents();
        this.setLocationRelativeTo(null);
        txtBúsqueda.setText("    Ingresa Carrera a Buscar...");
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel7 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        txtBúsqueda = new javax.swing.JTextField();
        menu_Panel = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator5 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();
        jSeparator7 = new javax.swing.JSeparator();
        jSeparator8 = new javax.swing.JSeparator();
        sld_PaginaWeb = new javax.swing.JLabel();
        sld_Matricula = new javax.swing.JLabel();
        sld_Cursos = new javax.swing.JLabel();
        sld_Estadistica = new javax.swing.JLabel();
        sld_Registro = new javax.swing.JLabel();
        sld_Carreras = new javax.swing.JLabel();
        jLabel30 = new javax.swing.JLabel();
        jLabel31 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jPanel5 = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jPanel10 = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jPanel12 = new javax.swing.JPanel();
        jLabel20 = new javax.swing.JLabel();
        jPanel13 = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        jPanel14 = new javax.swing.JPanel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        jPanel15 = new javax.swing.JPanel();
        jLabel26 = new javax.swing.JLabel();
        jLabel27 = new javax.swing.JLabel();
        jPanel16 = new javax.swing.JPanel();
        jLabel28 = new javax.swing.JLabel();
        jLabel29 = new javax.swing.JLabel();
        jPanel17 = new javax.swing.JPanel();
        jLabel32 = new javax.swing.JLabel();
        jLabel33 = new javax.swing.JLabel();
        jPanel18 = new javax.swing.JPanel();
        jLabel34 = new javax.swing.JLabel();
        jLabel35 = new javax.swing.JLabel();
        jPanel19 = new javax.swing.JPanel();
        jLabel36 = new javax.swing.JLabel();
        jLabel37 = new javax.swing.JLabel();
        jPanel20 = new javax.swing.JPanel();
        jPanel21 = new javax.swing.JPanel();
        jPanel22 = new javax.swing.JPanel();
        jLabel38 = new javax.swing.JLabel();
        jPanel23 = new javax.swing.JPanel();
        jLabel39 = new javax.swing.JLabel();
        jPanel24 = new javax.swing.JPanel();
        jLabel40 = new javax.swing.JLabel();
        jPanel25 = new javax.swing.JPanel();
        jLabel41 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Menu_35px_2.png"))); // NOI18N
        jLabel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel1MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 10, 40, 60));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Male_User_35px.png"))); // NOI18N
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(1140, 20, 40, 50));
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 30, 110, 30));

        jLabel4.setFont(new java.awt.Font("Pristina", 0, 20)); // NOI18N
        jLabel4.setText("Universidad Tecnológica");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 10, -1, 60));
        jPanel1.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 60, 110, 10));

        jLabel7.setBackground(new java.awt.Color(245, 245, 245));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Search_25px.png"))); // NOI18N
        jLabel7.setOpaque(true);
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 20, 50, 40));

        jLabel10.setBackground(new java.awt.Color(245, 245, 245));
        jLabel10.setOpaque(true);
        jPanel1.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(340, 20, 20, 40));

        txtBúsqueda.setBackground(new java.awt.Color(245, 245, 245));
        txtBúsqueda.setFont(new java.awt.Font("Calibri Light", 0, 18)); // NOI18N
        txtBúsqueda.setBorder(null);
        txtBúsqueda.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBúsquedaActionPerformed(evt);
            }
        });
        jPanel1.add(txtBúsqueda, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 20, 640, 40));

        menu_Panel.setBackground(new java.awt.Color(36, 60, 156));
        menu_Panel.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        menu_Panel.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, 210, 40));
        menu_Panel.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 440, 320, 20));
        menu_Panel.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 320, 20));
        menu_Panel.add(jSeparator4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, 320, 20));
        menu_Panel.add(jSeparator5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 320, 20));
        menu_Panel.add(jSeparator6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, 320, 20));
        menu_Panel.add(jSeparator7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 320, 20));
        menu_Panel.add(jSeparator8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 380, 320, 20));

        sld_PaginaWeb.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        sld_PaginaWeb.setForeground(new java.awt.Color(255, 255, 255));
        sld_PaginaWeb.setText("  Página Web");
        menu_Panel.add(sld_PaginaWeb, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 380, 320, 60));

        sld_Matricula.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        sld_Matricula.setForeground(new java.awt.Color(255, 255, 255));
        sld_Matricula.setText("  Matrícula");
        sld_Matricula.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sld_MatriculaMouseClicked(evt);
            }
        });
        menu_Panel.add(sld_Matricula, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 80, 320, 60));

        sld_Cursos.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        sld_Cursos.setForeground(new java.awt.Color(255, 255, 255));
        sld_Cursos.setText("  Cursos");
        sld_Cursos.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sld_CursosMouseClicked(evt);
            }
        });
        menu_Panel.add(sld_Cursos, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 140, 320, 60));

        sld_Estadistica.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        sld_Estadistica.setForeground(new java.awt.Color(255, 255, 255));
        sld_Estadistica.setText("  Estadística");
        sld_Estadistica.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sld_EstadisticaMouseClicked(evt);
            }
        });
        menu_Panel.add(sld_Estadistica, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 200, 320, 60));

        sld_Registro.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        sld_Registro.setForeground(new java.awt.Color(255, 255, 255));
        sld_Registro.setText("  Registro");
        sld_Registro.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sld_RegistroMouseClicked(evt);
            }
        });
        menu_Panel.add(sld_Registro, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 260, 320, 60));

        sld_Carreras.setFont(new java.awt.Font("Calibri Light", 0, 20)); // NOI18N
        sld_Carreras.setForeground(new java.awt.Color(255, 255, 255));
        sld_Carreras.setText("Financiamiento");
        sld_Carreras.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                sld_CarrerasMouseClicked(evt);
            }
        });
        menu_Panel.add(sld_Carreras, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 320, 320, 60));

        jLabel30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Exit_30px_1.png"))); // NOI18N
        menu_Panel.add(jLabel30, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 520, 30, 50));

        jLabel31.setFont(new java.awt.Font("Pristina", 0, 20)); // NOI18N
        jLabel31.setForeground(new java.awt.Color(255, 255, 255));
        jLabel31.setText("    Universidad Tecnológica");
        menu_Panel.add(jLabel31, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 520, 200, 60));

        jPanel1.add(menu_Panel, new org.netbeans.lib.awtextra.AbsoluteConstraints(-320, 0, 320, 580));

        jPanel2.setBackground(new java.awt.Color(36, 60, 156));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel6.setFont(new java.awt.Font("Calibri Light", 0, 16)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("  Carreras");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 80, 30));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Profiles_100px_1.png"))); // NOI18N
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, 110, 110));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 160, 500, 140));

        jPanel3.setBackground(new java.awt.Color(36, 60, 156));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Calibri Light", 0, 16)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("  Página Web");
        jPanel3.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 100, 30));

        jLabel19.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Website_100px_1.png"))); // NOI18N
        jPanel3.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 100, 90));

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 310, 240, 140));

        jPanel4.setBackground(new java.awt.Color(36, 60, 156));
        jPanel4.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Calibri Light", 0, 16)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("  Estadística");
        jPanel4.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 80, 30));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Combo_Chart_100px_2.png"))); // NOI18N
        jPanel4.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 10, 120, 110));

        jPanel1.add(jPanel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 310, 490, 140));

        jPanel5.setBackground(new java.awt.Color(36, 60, 156));
        jPanel5.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setFont(new java.awt.Font("Calibri Light", 0, 16)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("  Matrícula");
        jPanel5.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 80, 30));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Study_100px_1.png"))); // NOI18N
        jPanel5.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 120, 90));

        jPanel1.add(jPanel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 240, 140));

        jPanel6.setBackground(new java.awt.Color(36, 60, 156));
        jPanel6.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Calibri Light", 0, 16)); // NOI18N
        jLabel12.setForeground(new java.awt.Color(255, 255, 255));
        jLabel12.setText("  Registro");
        jPanel6.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 80, 30));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Registration_96px.png"))); // NOI18N
        jPanel6.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 30, 110, 90));

        jPanel1.add(jPanel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 160, 490, 140));

        jPanel7.setBackground(new java.awt.Color(36, 60, 156));
        jPanel7.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel13.setFont(new java.awt.Font("Calibri Light", 0, 16)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("  Cursos");
        jPanel7.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 80, 30));

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Course_Assign_100px.png"))); // NOI18N
        jPanel7.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, 100, 100));

        jPanel1.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 310, 240, 140));

        jPanel8.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 390, -1, 60));

        jPanel9.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jPanel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 310, -1, 70));

        jPanel10.setBackground(new java.awt.Color(36, 60, 156));
        jPanel10.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Play_Button_30px_1.png"))); // NOI18N
        jPanel10.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 30, 40));

        jPanel1.add(jPanel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 380, 120, 70));

        jPanel11.setBackground(new java.awt.Color(36, 60, 156));
        jPanel11.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_LinkedIn_30px.png"))); // NOI18N
        jPanel11.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 40, 40));

        jPanel1.add(jPanel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 380, 120, 70));

        jPanel12.setBackground(new java.awt.Color(36, 60, 156));
        jPanel12.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Facebook_F_30px_1.png"))); // NOI18N
        jPanel12.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 40, 40));

        jPanel1.add(jPanel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 310, 120, 60));

        jPanel13.setBackground(new java.awt.Color(36, 60, 156));
        jPanel13.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Twitter_30px_1.png"))); // NOI18N
        jPanel13.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, -1, 40));

        jPanel1.add(jPanel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 310, 120, 60));

        jPanel14.setBackground(new java.awt.Color(36, 60, 156));
        jPanel14.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel24.setFont(new java.awt.Font("Calibri Light", 0, 16)); // NOI18N
        jLabel24.setForeground(new java.awt.Color(255, 255, 255));
        jLabel24.setText("  Carreras");
        jPanel14.add(jLabel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 80, 30));

        jLabel25.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Profiles_100px_1.png"))); // NOI18N
        jPanel14.add(jLabel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 10, 110, 110));

        jPanel1.add(jPanel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 160, 500, 140));

        jPanel15.setBackground(new java.awt.Color(36, 60, 156));
        jPanel15.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel26.setFont(new java.awt.Font("Calibri Light", 0, 16)); // NOI18N
        jLabel26.setForeground(new java.awt.Color(255, 255, 255));
        jLabel26.setText("  Página Web");
        jPanel15.add(jLabel26, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 100, 30));

        jLabel27.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Website_100px_1.png"))); // NOI18N
        jPanel15.add(jLabel27, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 20, 100, 90));

        jPanel1.add(jPanel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 310, 240, 140));

        jPanel16.setBackground(new java.awt.Color(36, 60, 156));
        jPanel16.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel28.setFont(new java.awt.Font("Calibri Light", 0, 16)); // NOI18N
        jLabel28.setForeground(new java.awt.Color(255, 255, 255));
        jLabel28.setText("  Estadística");
        jPanel16.add(jLabel28, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 80, 30));

        jLabel29.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Combo_Chart_100px_2.png"))); // NOI18N
        jPanel16.add(jLabel29, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 10, 120, 110));

        jPanel1.add(jPanel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 310, 490, 140));

        jPanel17.setBackground(new java.awt.Color(36, 60, 156));
        jPanel17.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel32.setFont(new java.awt.Font("Calibri Light", 0, 16)); // NOI18N
        jLabel32.setForeground(new java.awt.Color(255, 255, 255));
        jLabel32.setText("  Matrícula");
        jPanel17.add(jLabel32, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 80, 30));

        jLabel33.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Study_100px_1.png"))); // NOI18N
        jPanel17.add(jLabel33, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 120, 90));

        jPanel1.add(jPanel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 240, 140));

        jPanel18.setBackground(new java.awt.Color(36, 60, 156));
        jPanel18.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel34.setFont(new java.awt.Font("Calibri Light", 0, 16)); // NOI18N
        jLabel34.setForeground(new java.awt.Color(255, 255, 255));
        jLabel34.setText("  Registro");
        jPanel18.add(jLabel34, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 80, 30));

        jLabel35.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Registration_96px.png"))); // NOI18N
        jPanel18.add(jLabel35, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 20, 110, 90));

        jPanel1.add(jPanel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(310, 160, 490, 140));

        jPanel19.setBackground(new java.awt.Color(36, 60, 156));
        jPanel19.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel36.setFont(new java.awt.Font("Calibri Light", 0, 16)); // NOI18N
        jLabel36.setForeground(new java.awt.Color(255, 255, 255));
        jLabel36.setText("  Cursos");
        jPanel19.add(jLabel36, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 110, 80, 30));

        jLabel37.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Course_Assign_100px.png"))); // NOI18N
        jPanel19.add(jLabel37, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 10, 100, 100));

        jPanel1.add(jPanel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 310, 240, 140));

        jPanel20.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jPanel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 390, -1, 60));

        jPanel21.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jPanel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 310, -1, 70));

        jPanel22.setBackground(new java.awt.Color(36, 60, 156));
        jPanel22.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel38.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Play_Button_30px_1.png"))); // NOI18N
        jPanel22.add(jLabel38, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 30, 40));

        jPanel1.add(jPanel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 380, 120, 70));

        jPanel23.setBackground(new java.awt.Color(36, 60, 156));
        jPanel23.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel39.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_LinkedIn_30px.png"))); // NOI18N
        jPanel23.add(jLabel39, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 40, 40));

        jPanel1.add(jPanel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 380, 120, 70));

        jPanel24.setBackground(new java.awt.Color(36, 60, 156));
        jPanel24.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel40.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Facebook_F_30px_1.png"))); // NOI18N
        jPanel24.add(jLabel40, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, 40, 40));

        jPanel1.add(jPanel24, new org.netbeans.lib.awtextra.AbsoluteConstraints(1060, 310, 120, 60));

        jPanel25.setBackground(new java.awt.Color(36, 60, 156));
        jPanel25.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel41.setIcon(new javax.swing.ImageIcon(getClass().getResource("/images/icons8_Twitter_30px_1.png"))); // NOI18N
        jPanel25.add(jLabel41, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 10, -1, 40));

        jPanel1.add(jPanel25, new org.netbeans.lib.awtextra.AbsoluteConstraints(1190, 310, 120, 60));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1351, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 575, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel1MouseClicked

        int x = menu_Panel.getX();

        if (x > 0) {

            Animacion.Animacion.mover_izquierda(5, -320, 3, 2, menu_Panel);

        } else {

            Animacion.Animacion.mover_derecha(-320, 5, 3, 2, menu_Panel);

        }
    }//GEN-LAST:event_jLabel1MouseClicked

    private void txtBúsquedaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBúsquedaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBúsquedaActionPerformed

    private void sld_MatriculaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sld_MatriculaMouseClicked

        ingresoController in = new ingresoController();
    
        this.dispose();

    }//GEN-LAST:event_sld_MatriculaMouseClicked

    private void sld_CursosMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sld_CursosMouseClicked
        CusosDisp c = new CusosDisp();
        c.setVisible(true);
        this.dispose();

    }//GEN-LAST:event_sld_CursosMouseClicked

    private void sld_EstadisticaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sld_EstadisticaMouseClicked
        JFEstadistica e = new JFEstadistica();
        e.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_sld_EstadisticaMouseClicked

    private void sld_RegistroMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sld_RegistroMouseClicked
        Estudiantes es = new Estudiantes();
         es.setVisible(true);
    
    }//GEN-LAST:event_sld_RegistroMouseClicked

    private void sld_CarrerasMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_sld_CarrerasMouseClicked
        financiamientoController f = new financiamientoController();
       
        this.dispose();
    }//GEN-LAST:event_sld_CarrerasMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JFMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JFMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JFMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JFMenu.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JFMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel28;
    private javax.swing.JLabel jLabel29;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel31;
    private javax.swing.JLabel jLabel32;
    private javax.swing.JLabel jLabel33;
    private javax.swing.JLabel jLabel34;
    private javax.swing.JLabel jLabel35;
    private javax.swing.JLabel jLabel36;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel38;
    private javax.swing.JLabel jLabel39;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel40;
    private javax.swing.JLabel jLabel41;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel14;
    private javax.swing.JPanel jPanel15;
    private javax.swing.JPanel jPanel16;
    private javax.swing.JPanel jPanel17;
    private javax.swing.JPanel jPanel18;
    private javax.swing.JPanel jPanel19;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel20;
    private javax.swing.JPanel jPanel21;
    private javax.swing.JPanel jPanel22;
    private javax.swing.JPanel jPanel23;
    private javax.swing.JPanel jPanel24;
    private javax.swing.JPanel jPanel25;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator5;
    private javax.swing.JSeparator jSeparator6;
    private javax.swing.JSeparator jSeparator7;
    private javax.swing.JSeparator jSeparator8;
    private javax.swing.JPanel menu_Panel;
    private javax.swing.JLabel sld_Carreras;
    private javax.swing.JLabel sld_Cursos;
    private javax.swing.JLabel sld_Estadistica;
    private javax.swing.JLabel sld_Matricula;
    private javax.swing.JLabel sld_PaginaWeb;
    private javax.swing.JLabel sld_Registro;
    public javax.swing.JTextField txtBúsqueda;
    // End of variables declaration//GEN-END:variables
}
