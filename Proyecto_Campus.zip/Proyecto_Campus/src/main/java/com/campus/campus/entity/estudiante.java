package com.campus.campus.entity;

/**
 *
 * @author Adriel
 */
public class estudiante {

    int idEstudiante;
    String Nombre, apellidoPaterno, apellidoMaterno;
    int NumeroTelefonico;
    String Correo, Direccion, Distrito, Canton, Provincia;
    int id_usuario, Clave;

    public estudiante(int idEstudiante, String Nombre, String apellidoPaterno, String apellidoMaterno, int NumeroTelefonico, String Correo, String Direccion, String Distrito, String Canton, String Provincia, int id_usuario, int clave) {
        this.idEstudiante = idEstudiante;
        this.Nombre = Nombre;
        this.apellidoPaterno = apellidoPaterno;
        this.apellidoMaterno = apellidoMaterno;
        this.NumeroTelefonico = NumeroTelefonico;
        this.Correo = Correo;
        this.Direccion = Direccion;
        this.Distrito = Distrito;
        this.Canton = Canton;
        this.Provincia = Provincia;
        this.id_usuario = id_usuario;
        this.Clave = clave;
    }

    public int getIdEstudiante() {
        return idEstudiante;
    }

    public void setIdEstudiante(int idEstudiante) {
        this.idEstudiante = idEstudiante;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public String getApellidoPaterno() {
        return apellidoPaterno;
    }

    public void setApellidoPaterno(String apellidoPaterno) {
        this.apellidoPaterno = apellidoPaterno;
    }

    public String getApellidoMaterno() {
        return apellidoMaterno;
    }

    public void setApellidoMaterno(String apellidoMaterno) {
        this.apellidoMaterno = apellidoMaterno;
    }

    public int getNumeroTelefonico() {
        return NumeroTelefonico;
    }

    public void setNumeroTelefonico(int NumeroTelefonico) {
        this.NumeroTelefonico = NumeroTelefonico;
    }

    public String getCorreo() {
        return Correo;
    }

    public void setCorreo(String Correo) {
        this.Correo = Correo;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String Direccion) {
        this.Direccion = Direccion;
    }

    public String getDistrito() {
        return Distrito;
    }

    public void setDistrito(String Distrito) {
        this.Distrito = Distrito;
    }

    public String getCanton() {
        return Canton;
    }

    public void setCanton(String Canton) {
        this.Canton = Canton;
    }

    public String getProvincia() {
        return Provincia;
    }

    public void setProvincia(String Provincia) {
        this.Provincia = Provincia;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }
    
    
}
