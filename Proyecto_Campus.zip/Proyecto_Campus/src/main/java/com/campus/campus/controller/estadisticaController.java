package com.campus.campus.controller;

import com.campus.campus.model.estadisticaDAO;
import com.campus.campus.model.generarGrafica;
import com.campus.campus.view.JFEstadistica;
import java.awt.BorderLayout;
import java.awt.Color;
import java.io.File;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.title.Title;
import org.jfree.data.category.CategoryDataset;
import org.jfree.data.general.DatasetUtilities;
import org.jfree.data.xy.XYSeries;
import org.jfree.data.xy.XYSeriesCollection;

public class estadisticaController {

    public static final int ANCHO_GRAFICA = 400;
    public static final int ALTO_GRAFICA = 300;
    estadisticaDAO e = new estadisticaDAO();
    
    JFEstadistica estadisticaView = new JFEstadistica();

    public estadisticaController() {
        estadisticaView.setVisible(true);
        estadisticaView.setLocationRelativeTo(null);
        //RenderChart();
        cargar();
        
        try {
            estadisticaView.Ntxt1.setText(" " + e.datos());
        } catch (SQLException ex) {
            System.out.println("ERROR "+ex);
        }
    }

    public CategoryDataset createDataset() {
        final double[][] data = new double[][]{
            {1.0, 4.0, 3.0, 5.0, 5.0, 7.0, 7.0, 8.0},
            {5.0, 7.0, 6.0, 8.0, 4.0, 4.0, 2.0, 1.0},
            {6.0, 6.0, 7.0, 7.0, 5.0, 3.0, 3.0, 1.0},
            {4.0, 3.0, 2.0, 3.0, 6.0, 3.0, 4.0, 3.0}
        };

        final CategoryDataset dataset = DatasetUtilities.createCategoryDataset(
                "", "", data
        );
        return dataset;
    }

    public void cargar() {
        
        try {
            final generarGrafica prueba = new generarGrafica();
            final JFreeChart grafica = prueba.crearGrafica(createDataset(), "Titulo", "EgeX", "EgeY");
            
            ChartPanel cp = new ChartPanel(grafica);
            cp.setBackground(new Color(255, 255, 255));

            estadisticaView.pnl_chart.add(cp, BorderLayout.CENTER);
            estadisticaView.pnl_chart.validate();
            
        } catch (Exception e) {
            System.out.println("Error "+ e);
        }
    }
}
