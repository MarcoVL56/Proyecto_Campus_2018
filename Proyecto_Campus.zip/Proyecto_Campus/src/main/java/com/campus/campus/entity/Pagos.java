/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.campus.campus.entity;

/**
 *
 * @author cesar
 */
public class Pagos {
    
    int monto;
    String formapago;
    int descuento;
    String fecha;
    

public Pagos(){

}
public Pagos(int monto,String formapago,int descuento,String fecha){
    
    this.monto=monto;
    this.descuento=descuento;
    this.formapago=formapago;
    this.fecha=fecha;
    
}

    public int getMonto() {
        return monto;
    }

    public void setMonto(int monto) {
        this.monto = monto;
    }

    public String getFormapago() {
        return formapago;
    }

    public void setFormapago(String formapago) {
        this.formapago = formapago;
    }

    public int getDescuento() {
        return descuento;
    }

    public void setDescuento(int descuento) {
        this.descuento = descuento;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

  
}