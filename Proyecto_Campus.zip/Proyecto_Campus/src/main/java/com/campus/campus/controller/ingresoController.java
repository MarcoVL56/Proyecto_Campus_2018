package com.campus.campus.controller;

import com.campus.campus.entity.estadoEstduante;
import com.campus.campus.entity.estudiante;
import com.campus.campus.model.connection;
import com.campus.campus.view.CusosDisp;
import com.campus.campus.view.IngresoAMatricula;
import com.campus.campus.view.JFMenu;
import java.awt.List;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.Action;
import javax.swing.JOptionPane;

public class ingresoController implements ActionListener {

    connection con;
    IngresoAMatricula iM = new IngresoAMatricula();
estadoEstduante eE =new estadoEstduante();
    
    
    int cedula;


    public ingresoController() {

        this.iM.setVisible(true);
        this.iM.setLocationRelativeTo(null);
        this.iM.btnIngresar.addActionListener(this);
        this.iM.btnAtras.addActionListener(this);

    }

    @Override

    //Se toca el boton y se va a esta locacion
    public void actionPerformed(ActionEvent ae) {

        if (ae.getSource() == iM.btnIngresar) {

            String nombre = String.valueOf(iM.txtIngreasar.getText());
//            cedula();
//            acceder();
            cursosDController cD = new cursosDController();

            cD.setEstudiante(Integer.parseInt(iM.txtIngreasar.getText()));

            cD.setCarrera(iM.cmbCarrera.getSelectedIndex() + 1);

            cD.iniciar();

            CusosDisp cDS = new CusosDisp();

            cDS.lblCarrera.setText((String) iM.cmbCarrera.getSelectedItem());
            
             iM.dispose();
        
             
             
        }

    }
//
//    public void cedula() {
//
//        setCedula(Integer.parseInt(String.valueOf( iM.txtIngreasar)));
//
//    }
//
//    void acceder() {
//
//        con.connect();
//        Connection cn = con.getConnection();
//
//        String sql = "SELECT * FROM estudiante WHERE idEstudiante='" + cedula + "'";
//        try {
//            Statement st = cn.createStatement();
//            ResultSet rs = st.executeQuery(sql);
//            if (rs.next()) {
//                CusosDisp cursos = new CusosDisp();
//                cursos.setVisible(true);
//                cursos.setLocationRelativeTo(null);
//            }
//
//        } catch (SQLException ex) {
//
//        }
//    }

    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

}
